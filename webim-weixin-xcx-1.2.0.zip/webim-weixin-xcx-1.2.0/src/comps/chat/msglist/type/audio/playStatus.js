module.exports = {
	PLAYING: "playing",
	PAUSE: "pause",
	STOP: "stop",
};
